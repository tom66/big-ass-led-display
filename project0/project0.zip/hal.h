//*****************************************************************************
//
// MC Power Control Software
// (C) 2015, 2016 Thomas Oldbury
// (C) 2015, 2016 Vivien Pizzini
//
// This code submitted in part for University of Leeds ELEC3880 module
//
//*****************************************************************************

/***
 * HAL code: Hardware Abstraction Layer
 *
 * Abstractions and control interfaces for components connected to Tiva MCU,
 * such as GPIO outputs.
 *
 * Written by Thomas Oldbury
 */

#ifndef ___HAL_H
#define ___HAL_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>

#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"

#include "inc/hw_gpio.h"
#include "inc/hw_memmap.h"
#include "inc/hw_sysctl.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_udma.h"
#include "inc/hw_ssi.h"
#include "driverlib/debug.h"
#include "driverlib/adc.h"
#include "driverlib/udma.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "driverlib/rom.h"
#include "driverlib/ssi.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/timer.h"
#include "driverlib/hibernate.h"
#include "driverlib/pwm.h"

#include "uartstdio.h"

#define SW_DEBUG_MODE					0							// debug mode 0: blat out debug messages in human form over UART
																						// debug mode 1: UART is reserved for VFD only

#define HAL_MAIN_PWR_ON				0x00000001		// main bus power (+5VSW, +12VSW, B+10V) active
#define HAL_RASPI_PWR_ON			0x00000002		// raspberry pi power (+5VRASPI) active
#define HAL_MOTOR_BUS_ON			0x00000004		// motor bus active and charged

#define ADC_MUTEX_OFF					0xcafed00d		// mutex OFF value
#define ADC_MUTEX_ON					0xcafebabe		// mutex ON value

#define UART_RASPI_BAUD				115200
#define UART_DEBUG_BAUD				115200
#define UART_BLE_BAUD					9600

#define TMR_GEN_RES_HZ				8000			
#define TMR_10MS_DIVIDER			80				
#define RES_LED_DIVIDER				400
#define RES_FAN_DIVIDER				80
#define TMR_MUTEX_ADC_WARN		800						// if ADC mutex held for too long emit a warning as a bugcheck
#define TMR_ADC_CALC_DIV			320						// number of ticks between slow ADC measurements in an ideal world.
																						// if mutex held after this time, it will wait, but the energy measurements will
																						// still be accurate on the next tick.
																						
// if you change these carefully scaled values things will break and Tom will hurt you
// 68719476736ULL = 2^36 [not some magic bullshit (although, it looks pretty close)]
// ultimate divider of 2^27 to get nominal scale of 1mAh for output variable
#define TMR_ADC_ENERGY_SCALE	((uint32_t)((1.0f / TMR_GEN_RES_HZ) * (1.0f / 3600.0f) * (330.0f / 512.0f) * 68719476736ULL))
#define TMR_ADC_ENERGY_SHIFT	27

#define ADC_ISNS_OFFS					139						// per board, needs calibration
#define ADC_ISNS_SCALE				7877					// 
#define ADC_VSNS_OFFS					-89						// 
#define ADC_VSNS_SCALE				9105					// 

#define ADC_VSNS_mV(code)			(((code * ADC_VSNS_SCALE) >> 10) + ADC_VSNS_OFFS)
#define ADC_ISNS_mA(code)			((((code - 2047) * ADC_ISNS_SCALE) >> 10) + ADC_ISNS_OFFS)
#define ADC_TEMP(code)				(14750 - ((24750 * code) >> 12))

// debug message macros
#if SW_DEBUG_MODE == 0
# define RAW_PRINTF(msg, ...)					UARTprintf(msg, __VA_ARGS__)
# define DBG_TIME(pre)								UARTprintf("[%s %5d.%02d] ", pre, timer_10ms_ticks / 100, timer_10ms_ticks % 100)
# define DBG_PRINTF(msg, ...)					(DBG_TIME("iii"),UARTprintf(msg, __VA_ARGS__))
# define WRN_PRINTF(msg, ...)					(DBG_TIME("WWW"),UARTprintf(msg, __VA_ARGS__))
# define ERR_PRINTF(msg, ...)					(DBG_TIME("EEE"),UARTprintf(msg, __VA_ARGS__))
# define DBG_ASSERT(cond)							if(!(cond)) { \
																				DBG_PRINTF("assertion failed " #cond " on line %d of file %s; resetting.\r\n", __LINE__, __FILE__) ;\
																				SysCtlReset(); }
#else
# define RAW_PRINTF(msg, ...)					(void*)0
# define DBG_PRINTF(msg, ...)					(void*)0
# define WRN_PRINTF(msg, ...)					(void*)0
# define ERR_PRINTF(msg, ...)					(void*)0
# define DBG_ASSERT(cond)							if(!(cond)) { SysCtlReset(); }
#endif

// raw data updated (if not read locked) at 8kHz rate
struct hal_adc_data_t {
	uint16_t vbat_vsns, vbat_isns, vchg_vsns, boost_isns, boost_inp_vsns, btn_analog, temp_tiva;
};

// corrected data updated at 25Hz rate for AI & remote control interface
struct hal_adc_corr_data_t {
	uint16_t vbat_mv;				// battery voltage, millivolts, at MC Power connector		(0-65535  mV)
	int16_t ibat_ma;				// battery current, milliamps, drawn by MC Power board 	(+/-32767 mA)
	int16_t pbat_mw;				// battery power, milliwatts, drawn by MC Power board 	(+/-32767 mW)
	int64_t bat_mah_accu;		// battery accumulated mAh (x 2^29)											(+/-32767.00000000 mAh)
	int64_t bat_mwh_accu;		// battery accumulated mWh (x 2^29)											(+/-32767.00000000 mWh)
	int16_t bat_mah;				// battery corrected mAh																(+/-32767 mAh)
	int16_t bat_mwh;				// battery corrected mWh																(+/-32767 mWh)
	int16_t tiva_temp;			// Tiva MCU temperature																	(-273.15C to +327.67C)
};

extern struct hal_adc_data_t adc_raw;							// do not use to read from
extern struct hal_adc_data_t adc_clean;						// use for reading
extern struct hal_adc_corr_data_t adc_corrected;	// corrected, accumulated data

extern uint32_t timer_10ms_ticks;

extern void Timer1AIntHandler(void);

void init_hw();
void init_uart();
void init_timers();
void gpio_led_ctrl(uint32_t led, uint32_t state);
void gpio_main_power_ctrl(uint32_t state);
void gpio_raspi_power_ctrl(uint32_t state);
void gpio_motor_power_on();
void gpio_motor_power_off();
void gpio_fan_ctrl_test(uint32_t state);
void gpio_park_brake_ctrl(uint32_t state);
// mutex for ADC data read out
void adc_set_read_mutex();
void adc_clear_read_mutex();

#endif // ___HAL_H
