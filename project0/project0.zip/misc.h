//*****************************************************************************
//
// MC Power Control Software
// (C) 2015, 2016 Thomas Oldbury
// (C) 2015, 2016 Vivien Pizzini
//
// This code submitted in part for University of Leeds ELEC3880 module
//
//*****************************************************************************

/***
 * Miscellaneous functions
 *
 * Written by Thomas Oldbury
 */

#ifndef ___MISC_H
#define ___MISC_H

#define MIN(x, y) 	(((x) < (y)) ? (x) : (y))
#define MAX(x, y)		(((x) > (y)) ? (x) : (y))

#endif // ___MISC_H
