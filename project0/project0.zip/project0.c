//*****************************************************************************
//
// MC Power Control Software
// (C) 2015, 2016 Thomas Oldbury
// (C) 2015, 2016 Vivien Pizzini
//
// This code submitted in part for University of Leeds ELEC3880 module
//
//*****************************************************************************

#include <stdint.h>
#include <stdbool.h>

#include "fan_therm.h"
#include "can.h"
#include "hal.h"

#include "uartstdio.h"

/***
 * Program entry point. 
 */
int main(void)
{
	uint32_t n = 0, j = 0, s = 0;
	uint8_t test_msg[8] = "\x55\x55\xcc\xcc\xf0\xf0\xff\x00";
	
	uint32_t testdelay = 10;
	int32_t testdir = 1;
	
	init_hw();
	
	RAW_PRINTF("\r\n\r\n", 0);
	RAW_PRINTF("MC Power Firmware v1.0.0\r\n", 0);
	RAW_PRINTF("(C) 2015, 2016 Thomas Oldbury\r\n", 0);
	RAW_PRINTF("(C) 2015, 2016 Vivien Pizzini\r\n", 0);
	RAW_PRINTF("Starting main application code\r\n", 0);
	RAW_PRINTF("\r\n", 0);
	
	SysCtlDelay(10000000);
	gpio_main_power_ctrl(1);
	SysCtlDelay(20000000);
	fan_set_target_speed(0);
	
	//GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6, GPIO_PIN_6);
	//GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7, GPIO_PIN_7);
	
	gpio_motor_power_on();
	SysCtlDelay(10000000);
	gpio_park_brake_ctrl(1);
	SysCtlDelay(10000000);
	gpio_raspi_power_ctrl(1);
	
	init_can();
	can_put_message(0xfff, 8, (uint8_t*)&test_msg);
	
	GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_4);
	GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_5);
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, ~GPIO_PIN_0);
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, ~GPIO_PIN_1);
	
	while(1) {
		//GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, GPIO_PIN_1);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_5);
		SysCtlDelay(testdelay);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_5);
		SysCtlDelay(10);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, GPIO_PIN_5);
		SysCtlDelay(300 - testdelay);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_5);
		SysCtlDelay(10);
		if(n >= 3000) {
			testdelay += testdir;
			if(testdelay > 50)
				testdir = -1;
			else if(testdelay < 2)
				testdir = 1;
			n = 0;
			j++;
			//if(testdir == -1)
			//	break;
			adc_set_read_mutex();
			DBG_PRINTF("V=%5d mV I=%5d mA P=%5d mW mAh=%5d mAh mWh=%5d mWh Temp=%5d\r\n", \
				adc_corrected.vbat_mv, adc_corrected.ibat_ma, adc_corrected.pbat_mw, adc_corrected.bat_mah, 
				adc_corrected.bat_mwh, adc_corrected.tiva_temp);
			adc_clear_read_mutex();
		}
		n++;
	}
	
	GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_4);
	GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_5);
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, ~GPIO_PIN_0);
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, ~GPIO_PIN_1);
	
	SysCtlDelay(100000);
	gpio_park_brake_ctrl(0);
	
	while(1) ; 
	
	
	while(1) {
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_5);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, ~GPIO_PIN_1);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, GPIO_PIN_0);
		SysCtlDelay(300);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_5);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, ~GPIO_PIN_1);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, ~GPIO_PIN_0);
		SysCtlDelay(1);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, GPIO_PIN_5);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, ~GPIO_PIN_1);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, ~GPIO_PIN_0);
		SysCtlDelay(300);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_5);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, ~GPIO_PIN_1);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, ~GPIO_PIN_0);
		SysCtlDelay(1);
	}
	
	while(1) {
		DBG_PRINTF("Vvsns=%d Visns=%d Temp=%d\r\n", \
			adc_raw.vbat_vsns, adc_raw.vbat_isns, adc_raw.temp_tiva);
	}
	
	while(1) {
		test_msg[0] = n >> 24;
		test_msg[1] = n >> 16;
		test_msg[2] = n >> 8;
		test_msg[3] = n;
		can_put_message(0xfff, 8, (uint8_t*)&test_msg);
		//SysCtlDelay(5000000);
		gpio_led_ctrl(1, s);
		s = 1 - s;
		n++;
	}
	
	GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
	GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_5);
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, ~GPIO_PIN_0);
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, ~GPIO_PIN_1);
	
	while(1) {
		//gpio_park_brake_ctrl(1);
		//SysCtlDelay(10000000);
		//gpio_park_brake_ctrl(0);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, GPIO_PIN_5);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, ~GPIO_PIN_0);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, GPIO_PIN_1);
		gpio_main_power_ctrl(1);
		SysCtlDelay(10000000);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_5);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, GPIO_PIN_0);
		GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, ~GPIO_PIN_1);
		gpio_main_power_ctrl(1);
		SysCtlDelay(10000000);
	}
	
	//gpio_fan_ctrl_test(1);
	while(1) {
		gpio_led_ctrl(1, s);
		s = 1 - s;
	}
	
	return 0;
}
