//*****************************************************************************
//
// MC Power Control Software
// (C) 2015, 2016 Thomas Oldbury
// (C) 2015, 2016 Vivien Pizzini
//
// This code submitted in part for University of Leeds ELEC3880 module
//
//*****************************************************************************

/***
 * CAN bus management routines, including interrupt handler.
 *
 * Written by Thomas Oldbury
 */

#ifndef ___CAN_H
#define ___CAN_H

#define CAN_BIT_RATE						1000000
#define CAN_RETRY_NUM						0

#define CAN_FLAG_MSG_OK					0x00000001		// message transmitted and acknowledged
#define CAN_FLAG_MSG_NACK				0x00000002		// message transmitted but NOT acknowledged
#define CAN_FLAG_MSG_NACK_ALL		0x00000004		// message transmitted but NOT acknowledged AND retry count exceeded
#define CAN_FLAG_MSG_SEND				0x00000008		// message transmit in progress

#define GPIO_LOCK_KEY_DD				0x4C4F434B		// NMI unmask

extern uint32_t can_nack_repeats, can_flags;

void init_can();
void CANIntHandler(void);
void can_put_message(uint32_t msg_id, uint32_t nbytes, uint8_t *data);

#endif // ___CAN_H