//*****************************************************************************
//
// MC Power Control Software
// (C) 2015, 2016 Thomas Oldbury
// (C) 2015, 2016 Vivien Pizzini
//
// This code submitted in part for University of Leeds ELEC3880 module
//
//*****************************************************************************

/***
 * HAL code: Hardware Abstraction Layer
 *
 * Abstractions and control interfaces for components connected to Tiva MCU,
 * such as GPIO outputs.
 *
 * Written by Thomas Oldbury
 */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "hal.h"
#include "fan_therm.h"

// TI UART STDIO driver, modified to print to different UARTs
#include "uartstdio.h"

uint32_t hal_flags = 0;
uint32_t timer_led_divider = 0;
uint32_t timer_fan_divider = 0;
uint32_t timer_heartbeat = 0;
// divide by TMR_10MS_DIVIDER [TMR_GEN_RES_HZ/100] to get exported timer figure
uint64_t timer_number_ticks = 0;
uint32_t timer_10ms_ticks = 0;
uint32_t timer_adc_mutex = 0;
uint32_t timer_adc_corr_counter = 0;
uint32_t timer_sub_div = TMR_10MS_DIVIDER;

// ADC mutex & data structs
uint32_t adc_mutex = ADC_MUTEX_OFF;
uint32_t adc_data_ready = 1;
struct hal_adc_data_t adc_raw;		// do not use to read from
struct hal_adc_data_t adc_clean;	// use for reading
struct hal_adc_corr_data_t adc_corrected;

/**
 * Timer1A interrupt handler: Global time-critical resource handling @ 8kHz.
 *
 * Responsible for: 
 *   ) Heartbeat LED
 *   ) Fan PWM & fan control
 *   ) ADC capture
 *   ) Battery energy measurement
 *   ) Button scan
 */
void Timer1AIntHandler(void)
{
	TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	// Start ADC sequencer, interrupt handler captures data
	ADCProcessorTrigger(ADC0_BASE, 0);
	timer_number_ticks++;
	timer_sub_div--;
	if(timer_sub_div == 0) {
		timer_sub_div = TMR_10MS_DIVIDER;
		timer_10ms_ticks++;
	}
	timer_fan_divider++;
	if(timer_fan_divider > RES_FAN_DIVIDER) {
		timer_fan_divider = 0;
		fan_sys_tick();
	}
	timer_led_divider++;
	if(timer_led_divider > RES_LED_DIVIDER) {
		timer_led_divider = 0;
		// switch heartbeat LED to next state
		timer_heartbeat++;
		if(timer_heartbeat == 1 || timer_heartbeat == 3)
			gpio_led_ctrl(0, 1);
		else
			gpio_led_ctrl(0, 0);
		if(timer_heartbeat > 6)
			timer_heartbeat = 0;
	}
	// Copy ADC data over if mutex isn't set.
	if(adc_mutex == ADC_MUTEX_OFF) {
		timer_adc_mutex = 0;
		if(adc_data_ready) {
			adc_clean.vbat_vsns = adc_raw.vbat_vsns;
			adc_clean.vbat_isns = adc_raw.vbat_isns;
			adc_clean.vchg_vsns = adc_raw.vchg_vsns;
			adc_clean.boost_isns = adc_raw.boost_isns;
			adc_clean.boost_inp_vsns = adc_raw.boost_inp_vsns;
			adc_clean.btn_analog = adc_raw.btn_analog;
			adc_data_ready = 0;
		}
	} else if(adc_mutex == ADC_MUTEX_ON) {
		timer_adc_mutex++;
		if(timer_adc_mutex == TMR_MUTEX_ADC_WARN) {
			WRN_PRINTF("ADC mutex held for some time. ADC data not being updated. Checked your code?\r\n", 0);
		}
	} else {
		ERR_PRINTF("Bugcheck!! ADC mutex value is bollocks (0x%08x). Something went really very wrong. "
							 "Like, really, memory corruption or something. Resetting CPU...\r\n", adc_mutex);
		SysCtlReset();
	}
	// Process "slow" ADC calculations (if mutex not occupied)
	if(timer_adc_corr_counter >= TMR_ADC_CALC_DIV && adc_mutex == ADC_MUTEX_OFF) {
		adc_corrected.vbat_mv = ADC_VSNS_mV(adc_clean.vbat_vsns);
		adc_corrected.ibat_ma = ADC_ISNS_mA(adc_clean.vbat_isns);
		adc_corrected.pbat_mw = (adc_corrected.vbat_mv * adc_corrected.ibat_ma) / 1000;
		// integrate energy (mWh) and mAh since last period. 
		// last period can be TMR_ADC_CALC_DIV or more ticks long, we need to scale by that
		// variable factor.
		adc_corrected.bat_mah_accu += adc_corrected.ibat_ma * TMR_ADC_ENERGY_SCALE;
		adc_corrected.bat_mah = adc_corrected.bat_mah_accu >> TMR_ADC_ENERGY_SHIFT;
		adc_corrected.bat_mwh_accu += adc_corrected.pbat_mw * TMR_ADC_ENERGY_SCALE;
		adc_corrected.bat_mwh = adc_corrected.bat_mwh_accu >> TMR_ADC_ENERGY_SHIFT;
		adc_corrected.tiva_temp = ADC_TEMP(adc_clean.temp_tiva);
		timer_adc_corr_counter = 0;
	}
	timer_adc_corr_counter++;
}

/**
 * ADC 0 sequence 0 IRQ handler, exports data from ADC sequencer into common data 
 * areas. Note the data will only be copied over when the mutex on the data is removed,
 * to avoid mid-read corruption occurring.
 */
void ADC0Seq0InterruptHandler()
{
	uint32_t adc_samples[8];
	ADCIntClear(ADC0_BASE, 0);
	ADCSequenceDataGet(ADC0_BASE, 0, (uint32_t*)&adc_samples);
	adc_raw.vbat_vsns = adc_samples[0];
	adc_raw.vbat_isns = adc_samples[1];
	adc_raw.temp_tiva = adc_samples[3];
	//adc_raw.vchg_vsns = adc_samples[2];
	//adc_raw.boost_isns = adc_samples[3];
	//adc_raw.boost_inp_vsns = adc_samples[4];
	//adc_raw.btn_analog = adc_samples[5];
	adc_data_ready = 1;
	//WRN_PRINTF("yo\r\n", 0);
}

/**
 * Initialise and prepare the hardware to begin executing code, which includes
 * starting the main oscillator.
 */
void init_hw()
{
	ROM_FPULazyStackingEnable();
	IntMasterEnable();
	SysCtlDelay(100000);
	SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ | SYSCTL_OSC_MAIN);
	SysCtlDelay(100000);
	// setup default GPIO states
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
	// LED pins off
	GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
	gpio_led_ctrl(0, 0);
	gpio_led_ctrl(1, 0);
	// motor power supply control outputs
	GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_7);
	GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_6);
	GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7, ~GPIO_PIN_7);
	GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6, ~GPIO_PIN_6);
	// motor PWM pins (default low GPIO until started)
	GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_4);
	GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_5);
	GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_0);
	GPIOPinTypeGPIOOutput(GPIO_PORTD_BASE, GPIO_PIN_1);
	GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
	GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_5, ~GPIO_PIN_5);
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_0, ~GPIO_PIN_0);
	GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_1, ~GPIO_PIN_1);
	// ADC configuration
	SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
	GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_0);	// VCHG_VSNS (AIN1)
	GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_1);	// VBAT_VSNS (AIN2)
	GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_2);	// VBAT_ISNS (AIN3)
	GPIOPinTypeADC(GPIO_PORTD_BASE, GPIO_PIN_3);	// BOOST_ISNS (AIN4)
	GPIOPinTypeADC(GPIO_PORTB_BASE, GPIO_PIN_4);	// BOOST_INP_VSNS (AIN10)
	GPIOPinTypeADC(GPIO_PORTB_BASE, GPIO_PIN_5);	// BTN_ANALOG (AIN11)
	// setup the read sequence at each 8kHz interrupt
	ADCHardwareOversampleConfigure(ADC0_BASE, 32);
	ADCSequenceConfigure(ADC0_BASE, 0, ADC_TRIGGER_PROCESSOR, 0);
	ADCSequenceStepConfigure(ADC0_BASE, 0, 0, ADC_CTL_CH1);								// first sample CH1
	ADCSequenceStepConfigure(ADC0_BASE, 0, 1, ADC_CTL_CH2);
	ADCSequenceStepConfigure(ADC0_BASE, 0, 2, ADC_CTL_CH3);
	ADCSequenceStepConfigure(ADC0_BASE, 0, 3, ADC_CTL_TS | ADC_CTL_IE | ADC_CTL_END);
	//ADCSequenceStepConfigure(ADC0_BASE, 0, 3, ADC_CTL_CH4);
	//ADCSequenceStepConfigure(ADC0_BASE, 0, 4, ADC_CTL_CH10);
	//ADCSequenceStepConfigure(ADC0_BASE, 0, 5, ADC_CTL_CH11);
	//ADCSequenceStepConfigure(ADC0_BASE, 0, 6, ADC_CTL_TS | ADC_CTL_IE | ADC_CTL_END);		// last sample Tiva temperature sensor
	ADCSequenceEnable(ADC0_BASE, 0);
	ADCIntClear(ADC0_BASE, 0);
	ADCIntEnable(ADC0_BASE, 0);
	IntEnable(INT_ADC0SS0);	
	// power rails off
	gpio_main_power_ctrl(0);
	// parking brake on
	gpio_park_brake_ctrl(0);
	// start processor resources
	init_fan_therm();
	init_uart();
	init_timers();
}

/*
 * Setup the UART ports.
 *
 * > UART1: debug output (115200 8N1) - this is printf() output port
 * > UART4: Vivien's BLE board (9600 8N1, may change)
 * > UART6: Raspberry Pi interface (~115200 8N1)
 */
void init_uart()
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART1);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART4);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART6);
	// VFD/debug interface (UART1)
	GPIOPinConfigure(GPIO_PB1_U1TX);
	GPIOPinConfigure(GPIO_PB0_U1RX);
	GPIOPinTypeUART(GPIO_PORTB_BASE, GPIO_PIN_1 | GPIO_PIN_0);
	UARTClockSourceSet(UART1_BASE, UART_CLOCK_SYSTEM);
	UARTStdioConfig(0, UART_DEBUG_BAUD, ROM_SysCtlClockGet());
	/*
	// BLE UART interface (UART4)
	UARTConfigSetExpClk(UART4_BASE, ROM_SysCtlClockGet(), UART_BLE_BAUD, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
	GPIOPinConfigure(GPIO_PC5_U4TX);
	GPIOPinConfigure(GPIO_PC4_U4RX);
	GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_5 | GPIO_PIN_4);
	// Raspberry Pi interface (UART6)
	UARTConfigSetExpClk(UART6_BASE, ROM_SysCtlClockGet(), UART_RASPI_BAUD, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
	GPIOPinConfigure(GPIO_PD5_U6TX);
	GPIOPinConfigure(GPIO_PD4_U6RX);
	GPIOPinTypeUART(GPIO_PORTD_BASE, GPIO_PIN_5 | GPIO_PIN_4);
	*/
}

/*
 * Setup global timers.
 *
 * > TIMER0: Servo control output
 * > TIMER1: General resource timer (@8kHz)
 * > TIMER5: Piezo beeper (freq. variable)
 */
void init_timers()
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);
	TimerConfigure(TIMER1_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_A_PERIODIC);
	TimerPrescaleSet(TIMER1_BASE, TIMER_A, 1);
	TimerLoadSet(TIMER1_BASE, TIMER_A, ROM_SysCtlClockGet() / TMR_GEN_RES_HZ);
	IntMasterEnable();
	IntPrioritySet(INT_TIMER1A, 0x20); // High priority
	TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
	IntEnable(INT_TIMER1A);
	TimerEnable(TIMER1_BASE, TIMER_A);
}

/**
 * Control status LEDs
 *
 * LED 0:  Heartbeat
 * LED 1:  Status/Error
 *
 * @param		led			Channel to set (0 or 1)
 * @param		state		0 = off, 1 = on
 */
void gpio_led_ctrl(uint32_t led, uint32_t state)
{
	uint32_t mask = 0x00;
	switch(led) {
		case 0:
			mask = GPIO_PIN_0;
			break;
		case 1:
			mask = GPIO_PIN_1;
			break;
	}
	if(state) {
		GPIOPinWrite(GPIO_PORTA_BASE, mask, mask);
	} else {
		GPIOPinWrite(GPIO_PORTA_BASE, mask, ~mask);
	}
}

/**
 * Switch main power rails on and off (+12VSW, B+10V & +5VSW)
 *
 * Note: If rails are switched off while +5VRASPI is active, that supply
 * will also be killed shortly afterwards. It is recommended that a shutdown
 * procedure be initiated beforehand.
 */
void gpio_main_power_ctrl(uint32_t state)
{
	if(state) {
		// power on by pulling HIGH
		GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4, GPIO_PIN_4);
		hal_flags |= HAL_MAIN_PWR_ON;
		DBG_PRINTF("Main power rails ON\r\n", 0);
	} else {
		// power off by pulling LOW
		GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_4);
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4, ~GPIO_PIN_4);
		hal_flags &= ~HAL_MAIN_PWR_ON;
		DBG_PRINTF("Main power rails OFF\r\n", 0);
	}
}

/**
 * Switch the +5VRASPI power supply on and off. Will also set power flag.
 *
 * Note: Main rails must be on beforehand.
 */
void gpio_raspi_power_ctrl(uint32_t state)
{
	if(state) {
		// power on by pulling HIGH
		GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_3);
		GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, GPIO_PIN_3);
		hal_flags |= HAL_RASPI_PWR_ON;
		DBG_PRINTF("Raspberry Pi power ON\r\n", 0);
	} else {
		// power off by pulling LOW
		GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_3);
		GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, ~GPIO_PIN_3);
		hal_flags &= ~HAL_RASPI_PWR_ON;
		DBG_PRINTF("Raspberry Pi power OFF\r\n", 0);
	}
}

/**
 * Precharge the motor power bus, then switch on the motor power path.
 *
 * If regen or charging are active, these functions will be aborted.
 *
 * Main power rails need to be on to generate the B+10V supply for the high
 * side gate drive. If these are not present, power will not be turned on.
 */
void gpio_motor_power_on()
{
	if(!(hal_flags & HAL_MAIN_PWR_ON)) {
		// debug_printf("ERR: Cannot engage motor power bus if main power bus (+12VSW, +5VSW, ...) is not active!\r\n");
		return;
	}
	// (TODO: If regen or charge active, these must be disabled.)
	// Precharge through resistors
	GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6, ~GPIO_PIN_6);
	GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7, GPIO_PIN_7);
	// (TODO: Measure bus voltage, needs to reach ~90% within 1 second to qualify)
	SysCtlDelay(8000000);
	GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6, GPIO_PIN_6);
	GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7, GPIO_PIN_7);
	SysCtlDelay(1000000);
	DBG_PRINTF("Motor power ON\r\n", 0);
}


/**
 * Isolate the motor power bus. 
 */
void gpio_motor_power_off()
{
	if(!(hal_flags & HAL_MAIN_PWR_ON)) {
		// debug_printf("ERR: Cannot engage motor power bus if main power bus (+12VSW, +5VSW, ...) is not active!\r\n");
		return;
	}
	// (TODO: If regen or charge active, these must be disabled.)
	// Precharge through resistors
	GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6, ~GPIO_PIN_6);
	GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7, GPIO_PIN_7);
	// (TODO: Measure bus voltage, needs to reach ~90% within 1 second to qualify)
	SysCtlDelay(1000000);
	GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6, GPIO_PIN_6);
	GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7, GPIO_PIN_7);
	SysCtlDelay(1000000);
	DBG_PRINTF("Motor power OFF\r\n", 0);
}

/**
 * Fan power control (test only: use PWM controller for proper operation)
 */
void gpio_fan_ctrl_test(uint32_t state)
{
	GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_7);
	if(state) {
		GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_7, GPIO_PIN_7);
	} else {
		GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_7, ~GPIO_PIN_7);
	}
}

/**
 * Parking relay direct contorl (use API to control park brake)
 */
void gpio_park_brake_ctrl(uint32_t state)
{
	GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_2);
	if(state) {
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, GPIO_PIN_2);
		DBG_PRINTF("Park brake relay OFF (output active)\r\n", 0);
	} else {
		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, ~GPIO_PIN_2);
		DBG_PRINTF("Park brake relay ON (output inactive)\r\n", 0);
	}
}

/**
 * Set the ADC read mutex. While set, the ADC values in the clean struct
 * and the corrected struct will never be updated. It is guaranteed by design 
 * that when this is set the data will remain untouched.
 *
 * Remember to clear the mutex as soon as you have read out what you need so 
 * the data can be updated by the timer interrupt.
 */
inline void adc_set_read_mutex()
{
	adc_mutex = ADC_MUTEX_ON;
}

/**
 * Set the ADC read mutex. While clear, the ADC values may be updated and
 * the ADC values should NOT be read unless you like to deal with weird
 * data corruption problems. **You have been warned.**
 */
inline void adc_clear_read_mutex()
{
	adc_mutex = ADC_MUTEX_OFF;
}

