//*****************************************************************************
//
// MC Power Control Software
// (C) 2015, 2016 Thomas Oldbury
// (C) 2015, 2016 Vivien Pizzini
//
// This code submitted in part for University of Leeds ELEC3880 module
//
//*****************************************************************************

/***
 * Fan & thermal management driver: Routines for measuring system temperatures
 * and controlling fan speed.  
 *
 * Written by Thomas Oldbury
 */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#include "hal.h"
#include "misc.h"
#include "fan_therm.h"

int16_t temp_pe, temp_amb, temp_batt, temp_mcu;
uint8_t fan_speed_demand = 0, fan_speed_current = 0;
uint32_t fan_speed_spinup_timer;
uint32_t fan_ctrl_flags;

/**
 * Prepare fan & thermal system
 */
void init_fan_therm()
{
	// Setup timer on PB7 for fan speed control using low frequency PWM (~50Hz)
	SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
	TimerConfigure(TIMER0_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_B_PWM);
	TimerPrescaleSet(TIMER0_BASE, TIMER_B, FAN_PWM_TIMER_SCALE);
	TimerPrescaleMatchSet(TIMER0_BASE, TIMER_B, 0);
	// LSBs for low-freq PWM can be ignored (2 & 1)
	TimerLoadSet(TIMER0_BASE, TIMER_B, 2);
	TimerMatchSet(TIMER0_BASE, TIMER_B, 1);
	TimerEnable(TIMER0_BASE, TIMER_B);
	GPIOPinConfigure(GPIO_PB7_T0CCP1);
	GPIOPinTypeTimer(GPIO_PORTB_BASE, GPIO_PIN_7);
	DBG_PRINTF("Fan/thermal module initialised\r\n", 0);
}

/** 
 * Set raw PWM fan speed directly (do not use outside of this libary)
 */
void fan_hal_ctrl_pwm(uint8_t duty)
{
	uint8_t match;
	match = (duty * FAN_PWM_TIMER_SCALE) >> FAN_PWM_TIMER_SHIFT;
	if(match > FAN_PWM_TIMER_SCALE)
		match = FAN_PWM_TIMER_SCALE;
	TimerPrescaleMatchSet(TIMER0_BASE, TIMER_B, FAN_PWM_TIMER_SCALE - match);
}

/*
 * Set the demand speed for the fan. Will initiate spinup if necessary.
 * Will switch fan to manual mode if override not in effect.
 */
void fan_set_target_speed(uint8_t speed)
{
	if(fan_ctrl_flags & FAN_FLAG_MODE_OVRD) 
		return;
	fan_ctrl_flags &= ~FAN_FLAG_MODE_AUTO;
	fan_ctrl_flags |= FAN_FLAG_MODE_MAN;
	DBG_PRINTF("New fanspeed command=%d flags=%08x\r\n", fan_speed_demand, fan_ctrl_flags);
	// if spinning fan UP go into spinup mode; don't spinup if we're slowing down...
	// also, don't restart the timer if we're already in a spinup window
	if(fan_speed_current < FAN_SPEED_MIN && speed >= fan_speed_demand) {
		fan_ctrl_flags |= FAN_FLAG_MODE_SPINUP;
		if(fan_ctrl_flags & ~FAN_FLAG_MODE_SPINUP) {
			fan_speed_spinup_timer = FAN_SPINUP_DELAY;
			DBG_PRINTF("Fan spinup start, flags=%08x, tmr=%d\r\n", fan_ctrl_flags, fan_speed_spinup_timer);
		}
	}
	fan_speed_demand = speed;
}

/*
 * System tick, run at 100Hz. Measures system temperatures and updates
 * any targetted fan speed.
 */
void fan_sys_tick()
{
	//DBG_PRINTF("Fanspeed: Cur=%d, Dmd=%d, Flags=%08x\r\n", fan_speed_current, fan_speed_demand, fan_ctrl_flags);
	if(fan_speed_spinup_timer > 0) {
		fan_speed_spinup_timer--;
		fan_speed_current = FAN_SPINUP_SET;
	} else {
		if(fan_ctrl_flags & FAN_FLAG_MODE_SPINUP) {
			DBG_PRINTF("Fan spinup period end, ramping speed to %d\r\n", fan_speed_demand);
			fan_ctrl_flags &= ~FAN_FLAG_MODE_SPINUP;
		}
		if(fan_speed_current < fan_speed_demand) {
			if(fan_speed_current < FAN_SPEED_MAX)
				fan_speed_current++;
		}	else if(fan_speed_current > fan_speed_demand) {
			if(fan_speed_current > 1)
				fan_speed_current--;
		}
	}
	fan_hal_ctrl_pwm(fan_speed_current);
}
