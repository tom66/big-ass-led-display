//*****************************************************************************
//
// MC Power Control Software
// (C) 2015, 2016 Thomas Oldbury
// (C) 2015, 2016 Vivien Pizzini
//
// This code submitted in part for University of Leeds ELEC3880 module
//
//*****************************************************************************

/***
 * CAN bus management routines, including interrupt handler.
 *
 * Written by Thomas Oldbury
 */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_can.h"
#include "inc/hw_ints.h"
#include "driverlib/can.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"

#include "hal.h"
#include "can.h"

uint32_t can_nack_repeats = 0;
uint32_t can_flags = 0;

/**
 * Setup CAN peripheral and interrupts
 */
void init_can()
{
	uint32_t can_clock;
	SysCtlPeripheralEnable(SYSCTL_PERIPH_CAN0);
	HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY_DD;
	HWREG(GPIO_PORTF_BASE + GPIO_O_CR) = 0x1;
	GPIOPinConfigure(GPIO_PF0_CAN0RX);
	GPIOPinConfigure(GPIO_PF3_CAN0TX);
	GPIOPinTypeCAN(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_3);
	CANInit(CAN0_BASE);
	can_clock = CANBitRateSet(CAN0_BASE, ROM_SysCtlClockGet(), CAN_BIT_RATE);
	CANIntRegister(CAN0_BASE, CANIntHandler); 
	CANIntEnable(CAN0_BASE, CAN_INT_MASTER | CAN_INT_ERROR | CAN_INT_STATUS);
	CANRetrySet(CAN0_BASE, 0); // don't auto retry
	IntEnable(INT_CAN0);
	CANEnable(CAN0_BASE);
	DBG_PRINTF("CAN0 ready, req=%d kHz, actual=%d kHz\r\n", CAN_BIT_RATE / 1000, can_clock / 1000);
}

/**
 * CAN peripheral interrupt
 */
void CANIntHandler(void) 
{	
	uint32_t err;
	uint32_t stat = CANIntStatus(CAN0_BASE, CAN_INT_STS_CAUSE);
	switch(stat) {
		case CAN_INT_INTID_STATUS:
			err = CANStatusGet(CAN0_BASE, CAN_STS_CONTROL);
			if(err & CAN_STATUS_BUS_OFF) {
				DBG_PRINTF("CAN: controller in BUS OFF mode\r\n", 0);
			}
			if(err & CAN_STATUS_EPASS) {
				WRN_PRINTF("CAN: controller reached error passive level\r\n", 0);
			}
			if(err & CAN_STATUS_EWARN) {
				WRN_PRINTF("CAN: controller reached error warning level\r\n", 0);
			}
			switch(err & CAN_STATUS_LEC_MSK) {
				case CAN_STATUS_LEC_STUFF:
					ERR_PRINTF("CAN: bit stuffing error\r\n", 0);
					break;
				case CAN_STATUS_LEC_FORM:
					ERR_PRINTF("CAN: formatting error\r\n", 0);
					break;
				case CAN_STATUS_LEC_ACK:
					WRN_PRINTF("CAN: last message NACK'd\r\n", 0);
					if(can_nack_repeats == 0) {
						//ERR_PRINTF("Too many NACKs, discarding message\r\n", 0);
						//ERR_PRINTF("", 0);
						CANMessageClear(CAN0_BASE, 1);
						can_flags |= CAN_FLAG_MSG_NACK_ALL;
					} 
					can_nack_repeats--;
					break;
				case CAN_STATUS_LEC_BIT1:
					ERR_PRINTF("CAN: bus remained ONE for too long\r\n", 0);
					break;
				case CAN_STATUS_LEC_BIT0:
					ERR_PRINTF("CAN: bus remained ZERO for too long\r\n", 0);
					break;
				case CAN_STATUS_LEC_CRC:
					ERR_PRINTF("CAN: CRC check failed\r\n", 0);
					break;
			}
			// clear flags on any event
			can_flags |= CAN_FLAG_MSG_OK;
			can_flags &= ~CAN_FLAG_MSG_SEND;
			break;
		case 1:
			break;
		default:
			ERR_PRINTF("Unexpected CANBUS interrupt status %d\r\n", stat);
			break;
	}
	CANIntClear(CAN0_BASE, 1);
}

/**
 * Set a message on the bus. The status of the message can be queried
 * later on using the appropriate functions XXXXXXX.
 */
void can_put_message(uint32_t msg_id, uint32_t nbytes, uint8_t *data)
{
	tCANMsgObject tx_msg;
	uint8_t msg_buffer[8];
	DBG_ASSERT(nbytes <= 8);
	// build the message struct and transmit it
	memset(msg_buffer, 0, nbytes);
	memcpy(msg_buffer, data, nbytes);
	tx_msg.ui32MsgID = msg_id;
	tx_msg.ui32MsgIDMask = 0;
	tx_msg.ui32Flags = MSG_OBJ_TX_INT_ENABLE;
	tx_msg.ui32MsgLen = nbytes;
	tx_msg.pui8MsgData = msg_buffer;
	// wait if message is already being transmitted
	if(can_flags & CAN_FLAG_MSG_SEND) {
		WRN_PRINTF("Waiting for free transmit time\r\n", 0);
		while(can_flags & CAN_FLAG_MSG_SEND) ; 
	}
	can_flags &= ~(CAN_FLAG_MSG_NACK_ALL | CAN_FLAG_MSG_NACK | CAN_FLAG_MSG_OK | CAN_FLAG_MSG_SEND);
	// retry count
	can_nack_repeats = CAN_RETRY_NUM;
	CANMessageSet(CAN0_BASE, 1, &tx_msg, MSG_OBJ_TYPE_TX);
}
