//*****************************************************************************
//
// MC Power Control Software
// (C) 2015, 2016 Thomas Oldbury
// (C) 2015, 2016 Vivien Pizzini
//
// This code submitted in part for University of Leeds ELEC3880 module
//
//*****************************************************************************

/***
 * Fan & thermal management driver: Routines for measuring system temperatures
 * and controlling fan speed.  
 *
 * Written by Thomas Oldbury
 */

#ifndef ___FAN_THERM_H
#define ___FAN_THERM_H

#define FAN_SPINUP_DELAY			100				// spinup time in 10ms units (default 1 sec)
#define FAN_SPINUP_SET				255				// speed to use on spinup
#define FAN_SPEED_MIN					50				// speeds below this go to zero
#define FAN_SPEED_MAX					255				// maximum attainable speed
#define FAN_PWM_TIMER_SCALE		26				// 50Hz target frequency, this represents 100% duty
#define FAN_PWM_TIMER_DIV			256				// divider
#define FAN_PWM_TIMER_SHIFT		8					// shift for above divider

#define FAN_FLAG_MODE_AUTO		0x01			// auto fan speed
#define FAN_FLAG_MODE_MAN			0x02			// manual fan speed - will be overridden if cooling demand is high
#define FAN_FLAG_MODE_OVRD		0x04			// override in effect
#define FAN_FLAG_MODE_SPINUP	0x08			// spinup in effect

// Temperatures measured for power electronics, ambient environment, 
// battery (if bq chip placed), and the MCU.
//
// Range of -273.15 to +327.67C. If it gets to either of those extremes,
// then the robot is probably on fire or in the freezer. Neither is good.
extern int16_t temp_pe, temp_amb, temp_batt, temp_mcu;

// Current fan speed demand & actual result calculated as a result of 
// temperature and system mode (regen, drive, charge, etc.) Range 0-255.
extern uint8_t fan_speed_demand, fan_speed_current;

// If the fan speed starts at zero, then it is run at full speed briefly
// before being set to the current speed. When timer reaches zero, the current
// speed will begin dropping to meet the demanded speed.
extern uint32_t fan_speed_spinup_timer;

// Control flags
extern uint32_t fan_ctrl_flags;

// Prepare fan & thermal system
void init_fan_therm();

// Set the target speed for the fan. Will initiate spinup if necessary.
void fan_set_target_speed(uint8_t speed);

// Set raw PWM fan speed directly (do not use outside of this libary)
void fan_hal_ctrl_pwm(uint8_t duty);

// System tick, run at 100Hz. Measures system temperatures and updates
// any targetted fan speed.
void fan_sys_tick();

#endif // ___FAN_THERM_H
